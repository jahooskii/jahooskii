@echo off
REM Open Quan Lux Dashboard in default browser
start index.html
