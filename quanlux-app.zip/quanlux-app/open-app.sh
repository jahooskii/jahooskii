#!/bin/bash
# Open Quan Lux Dashboard in default browser
open index.html 2>/dev/null || xdg-open index.html 2>/dev/null || echo "Please open index.html in your web browser"
