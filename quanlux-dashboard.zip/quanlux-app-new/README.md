# Quan Lux - Luxury Chauffeur Dashboard

## Quick Start

1. **Open the dashboard:**
   - Double-click `index.html` to open in your browser
   - Or open it manually: `File → Open` and select `index.html`

2. **Login with your credentials:**
   - Your Firebase authentication is already configured
   - Use your admin account email and password to login

3. **Available Roles:**
   - CEO: Full access to all features
   - Dispatcher: Fleet and booking management
   - Driver: Driver console view
   - Rider: Rider portal

## Features

✓ Executive Dashboard with real-time analytics
✓ Fleet Management with live vehicle tracking
✓ Booking & Itinerary Management  
✓ Elite Client Concierge with barcode generation
✓ Driver Management & QR codes
✓ Financial Analytics
✓ Dispatch Command Center
✓ Rider Portal with fare estimation
✓ Mobile responsive design
✓ All data syncs with Firebase Firestore

## Privacy & Security

- All authentication uses your Firebase setup
- Data is encrypted and stored securely
- Sign out removes all session data
- Works completely offline after first load
- No external API calls except Firebase

## Support

All features are fully functional. If you encounter any issues, check:
1. Browser console for error messages
2. Firebase Firestore is accessible
3. Your internet connection (for initial load)

Enjoy your Quan Lux dashboard! 🚗✨
